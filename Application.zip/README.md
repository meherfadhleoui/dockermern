## run  project 
```bash
  docker-compose up --build 
```
## visit :  http://localhost:3050
